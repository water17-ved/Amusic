package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.SongEntity
import com.example.ui.LibraryTab
import com.example.ui.SortOrder
import com.example.ui.components.ArtworkImage

@Composable
fun LibraryScreen(
  songs: List<SongEntity>,
  currentTab: LibraryTab,
  onTabChange: (LibraryTab) -> Unit,
  sortOrder: SortOrder,
  onSortChange: (SortOrder) -> Unit,
  searchQuery: String,
  onSearchChange: (String) -> Unit,
  onSongClick: (SongEntity, List<SongEntity>) -> Unit,
  onToggleFavorite: (SongEntity) -> Unit,
  onAddToPlaylist: (SongEntity) -> Unit,
  onEditMetadata: (SongEntity) -> Unit,
  onRemoveSong: (SongEntity) -> Unit
) {
  var showSortMenu by remember { mutableStateOf(false) }

  Column(modifier = Modifier.fillMaxSize()) {
    // Header & Search
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Music Library",
          style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
        )

        Box {
          IconButton(onClick = { showSortMenu = true }) {
            Icon(Icons.Default.FilterList, contentDescription = "Sort order")
          }
          DropdownMenu(
            expanded = showSortMenu,
            onDismissRequest = { showSortMenu = false }
          ) {
            DropdownMenuItem(
              text = { Text("Title (A-Z)") },
              onClick = {
                onSortChange(SortOrder.TITLE_ASC)
                showSortMenu = false
              }
            )
            DropdownMenuItem(
              text = { Text("Artist (A-Z)") },
              onClick = {
                onSortChange(SortOrder.ARTIST_ASC)
                showSortMenu = false
              }
            )
            DropdownMenuItem(
              text = { Text("Recently Added") },
              onClick = {
                onSortChange(SortOrder.DATE_ADDED_DESC)
                showSortMenu = false
              }
            )
            DropdownMenuItem(
              text = { Text("Duration (Longest)") },
              onClick = {
                onSortChange(SortOrder.DURATION_DESC)
                showSortMenu = false
              }
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      OutlinedTextField(
        value = searchQuery,
        onValueChange = onSearchChange,
        leadingIcon = {
          Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary)
        },
        placeholder = { Text("Filter tracks, artists, albums...") },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        singleLine = true
      )
    }

    // Tabs
    TabRow(
      selectedTabIndex = currentTab.ordinal,
      containerColor = MaterialTheme.colorScheme.surface,
      contentColor = MaterialTheme.colorScheme.primary
    ) {
      LibraryTab.values().forEach { tab ->
        Tab(
          selected = currentTab == tab,
          onClick = { onTabChange(tab) },
          text = {
            Text(
              text = when (tab) {
                LibraryTab.TRACKS -> "Tracks (${songs.size})"
                LibraryTab.ARTISTS -> "Artists"
                LibraryTab.ALBUMS -> "Albums"
              }
            )
          }
        )
      }
    }

    when (currentTab) {
      LibraryTab.TRACKS -> {
        if (songs.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "No songs found.",
              style = MaterialTheme.typography.bodyLarge,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 8.dp, bottom = 110.dp)
          ) {
            items(songs) { song ->
              SongListItem(
                song = song,
                onClick = { onSongClick(song, songs) },
                onToggleFavorite = { onToggleFavorite(song) },
                onAddToPlaylist = { onAddToPlaylist(song) },
                onEditMetadata = { onEditMetadata(song) },
                onRemove = { onRemoveSong(song) }
              )
            }
          }
        }
      }

      LibraryTab.ARTISTS -> {
        val groupedByArtist = remember(songs) {
          songs.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() }
        }

        if (groupedByArtist.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "No artists found.",
              style = MaterialTheme.typography.bodyLarge,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 8.dp, bottom = 110.dp)
          ) {
            items(groupedByArtist) { (artist, artistSongs) ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 4.dp)
                  .clickable {
                    if (artistSongs.isNotEmpty()) {
                      onSongClick(artistSongs.first(), artistSongs)
                    }
                  },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                  containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  ArtworkImage(
                    artworkUri = artistSongs.firstOrNull()?.artworkUri,
                    title = artist,
                    modifier = Modifier.size(50.dp),
                    cornerRadius = 25.dp,
                    iconSize = 24.dp
                  )
                  Spacer(modifier = Modifier.width(16.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = artist,
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                      text = "${artistSongs.size} tracks",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                  IconButton(onClick = { onSongClick(artistSongs.first(), artistSongs) }) {
                    Icon(
                      imageVector = Icons.Default.PlayArrow,
                      contentDescription = "Play all by $artist",
                      tint = MaterialTheme.colorScheme.primary
                    )
                  }
                }
              }
            }
          }
        }
      }

      LibraryTab.ALBUMS -> {
        val groupedByAlbum = remember(songs) {
          songs.groupBy { it.album }.toList().sortedBy { it.first.lowercase() }
        }

        if (groupedByAlbum.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "No albums found.",
              style = MaterialTheme.typography.bodyLarge,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        } else {
          LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            items(groupedByAlbum) { (album, albumSongs) ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    if (albumSongs.isNotEmpty()) {
                      onSongClick(albumSongs.first(), albumSongs)
                    }
                  },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                  containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  ArtworkImage(
                    artworkUri = albumSongs.firstOrNull()?.artworkUri,
                    title = album,
                    modifier = Modifier
                      .fillMaxWidth()
                      .height(130.dp),
                    cornerRadius = 12.dp,
                    iconSize = 36.dp
                  )
                  Spacer(modifier = Modifier.height(8.dp))
                  Text(
                    text = album,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                  Text(
                    text = "${albumSongs.firstOrNull()?.artist} • ${albumSongs.size} tracks",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

package com.example.ui.util

import java.util.Locale
import java.util.concurrent.TimeUnit

object TimeUtils {

  fun formatMs(millis: Long): String {
    if (millis <= 0) return "0:00"
    val hours = TimeUnit.MILLISECONDS.toHours(millis)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60
    val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60

    return if (hours > 0) {
      String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
    } else {
      String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
    }
  }

  fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    return when {
      mb >= 1.0 -> String.format(Locale.getDefault(), "%.1f MB", mb)
      kb >= 1.0 -> String.format(Locale.getDefault(), "%.1f KB", kb)
      else -> "$bytes B"
    }
  }
}

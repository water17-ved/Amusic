package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.playback.PlaybackUiState
import com.example.playback.RepeatMode
import com.example.ui.components.ArtworkImage
import com.example.ui.util.TimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
  playbackState: PlaybackUiState,
  onDismiss: () -> Unit,
  onPlayPause: () -> Unit,
  onSkipNext: () -> Unit,
  onSkipPrevious: () -> Unit,
  onSeekTo: (Long) -> Unit,
  onToggleShuffle: () -> Unit,
  onToggleRepeat: () -> Unit,
  onToggleFavorite: () -> Unit,
  onOpenSleepTimer: () -> Unit,
  onQueueItemClick: (Int) -> Unit,
  onRemoveQueueItem: (Int) -> Unit
) {
  val song = playbackState.currentSong ?: return
  var showQueueSheet by remember { mutableStateOf(false) }

  // Dragging slider state
  var isDragging by remember { mutableStateOf(false) }
  var dragPosition by remember { mutableFloatStateOf(0f) }

  val progressMs = if (isDragging) {
    (dragPosition * playbackState.durationMs).toLong()
  } else {
    playbackState.currentPositionMs
  }

  Surface(
    modifier = Modifier.fillMaxSize(),
    color = MaterialTheme.colorScheme.background
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp, vertical = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top bar: Dismiss & Sleep timer
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onDismiss) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close player",
            tint = MaterialTheme.colorScheme.onBackground
          )
        }

        Text(
          text = "NOW PLAYING",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        IconButton(onClick = onOpenSleepTimer) {
          Icon(
            imageVector = Icons.Default.Bedtime,
            contentDescription = "Sleep timer",
            tint = if (playbackState.sleepTimerRemainingSec != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Big Artwork Display
      Box(
        modifier = Modifier
          .size(280.dp)
          .shadow(24.dp, RoundedCornerShape(24.dp)),
        contentAlignment = Alignment.Center
      ) {
        ArtworkImage(
          artworkUri = song.artworkUri,
          title = song.title,
          modifier = Modifier.fillMaxSize(),
          cornerRadius = 24.dp,
          iconSize = 80.dp
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Title & Artist with Favorite Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = song.title,
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "${song.artist} • ${song.album}",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }

        IconButton(onClick = onToggleFavorite) {
          Icon(
            imageVector = if (song.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Favorite",
            tint = if (song.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(28.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Scrub Slider & Timestamps
      Column(modifier = Modifier.fillMaxWidth()) {
        val sliderValue = if (playbackState.durationMs > 0) {
          (progressMs.toFloat() / playbackState.durationMs.toFloat()).coerceIn(0f, 1f)
        } else {
          0f
        }

        Slider(
          value = sliderValue,
          onValueChange = {
            isDragging = true
            dragPosition = it
          },
          onValueChangeFinished = {
            isDragging = false
            onSeekTo((dragPosition * playbackState.durationMs).toLong())
          },
          colors = SliderDefaults.colors(
            thumbColor = MaterialTheme.colorScheme.primary,
            activeTrackColor = MaterialTheme.colorScheme.primary,
            inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
          ),
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = TimeUtils.formatMs(progressMs),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = TimeUtils.formatMs(playbackState.durationMs),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Playback Controls Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Shuffle
        IconButton(onClick = onToggleShuffle) {
          Icon(
            imageVector = Icons.Default.Shuffle,
            contentDescription = "Shuffle",
            tint = if (playbackState.isShuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        // Previous
        IconButton(
          onClick = onSkipPrevious,
          modifier = Modifier.size(48.dp)
        ) {
          Icon(
            imageVector = Icons.Default.SkipPrevious,
            contentDescription = "Previous",
            modifier = Modifier.size(36.dp)
          )
        }

        // Play/Pause
        Box(
          modifier = Modifier
            .size(68.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary)
            .clickable { onPlayPause() },
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (playbackState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
            contentDescription = if (playbackState.isPlaying) "Pause" else "Play",
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(36.dp)
          )
        }

        // Next
        IconButton(
          onClick = onSkipNext,
          modifier = Modifier.size(48.dp)
        ) {
          Icon(
            imageVector = Icons.Default.SkipNext,
            contentDescription = "Next",
            modifier = Modifier.size(36.dp)
          )
        }

        // Repeat
        IconButton(onClick = onToggleRepeat) {
          val icon = if (playbackState.repeatMode == RepeatMode.ONE) Icons.Default.RepeatOne else Icons.Default.Repeat
          val tint = if (playbackState.repeatMode != RepeatMode.OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
          Icon(
            imageVector = icon,
            contentDescription = "Repeat",
            tint = tint
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Bottom Row: Queue Sheet Trigger & Sleep Timer indicator
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { showQueueSheet = true }
          .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.QueueMusic,
          contentDescription = "Queue",
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Play Queue (${playbackState.queue.size} songs)",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.primary
        )
      }
    }
  }

  // Queue Modal Bottom Sheet
  if (showQueueSheet) {
    ModalBottomSheet(
      onDismissRequest = { showQueueSheet = false },
      sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp)
      ) {
        Text(
          text = "Upcoming Queue",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          modifier = Modifier.padding(bottom = 12.dp)
        )

        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .height(350.dp)
        ) {
          itemsIndexed(playbackState.queue) { index, queueSong ->
            val isCurrent = index == playbackState.currentIndex

            Card(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clickable {
                  onQueueItemClick(index)
                  showQueueSheet = false
                },
              colors = CardDefaults.cardColors(
                containerColor = if (isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
              )
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                ArtworkImage(
                  artworkUri = queueSong.artworkUri,
                  title = queueSong.title,
                  modifier = Modifier.size(36.dp),
                  cornerRadius = 6.dp,
                  iconSize = 16.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = queueSong.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                  Text(
                    text = queueSong.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
                IconButton(onClick = { onRemoveQueueItem(index) }) {
                  Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove from queue",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MusicApplication
import com.example.data.model.PlaylistEntity
import com.example.data.model.SongEntity
import com.example.playback.MusicPlaybackController
import com.example.playback.PlaybackUiState
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class LibraryTab {
  TRACKS, ARTISTS, ALBUMS
}

enum class SortOrder {
  TITLE_ASC, ARTIST_ASC, DATE_ADDED_DESC, DURATION_DESC
}

sealed class ActiveDialog {
  data class AddToPlaylist(val song: SongEntity) : ActiveDialog()
  data class EditMetadata(val song: SongEntity) : ActiveDialog()
  data class RemoveFromLibrary(val song: SongEntity) : ActiveDialog()
  object SleepTimer : ActiveDialog()
  object CleanStorage : ActiveDialog()
  object ImportPlaylist : ActiveDialog()
}

class MusicViewModel(application: Application) : AndroidViewModel(application) {

  private val app = application as MusicApplication
  private val repository = app.repository
  private val controller = app.playbackController

  val playbackState: StateFlow<PlaybackUiState> = controller.uiState

  val allSongs: StateFlow<List<SongEntity>> = repository.allSongs
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val favoriteSongs: StateFlow<List<SongEntity>> = repository.favoriteSongs
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val playlists: StateFlow<List<PlaylistEntity>> = repository.allPlaylists
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _sortOrder = MutableStateFlow(SortOrder.TITLE_ASC)
  val sortOrder: StateFlow<SortOrder> = _sortOrder.asStateFlow()

  private val _libraryTab = MutableStateFlow(LibraryTab.TRACKS)
  val libraryTab: StateFlow<LibraryTab> = _libraryTab.asStateFlow()

  private val _activePlaylist = MutableStateFlow<PlaylistEntity?>(null)
  val activePlaylist: StateFlow<PlaylistEntity?> = _activePlaylist.asStateFlow()

  @OptIn(ExperimentalCoroutinesApi::class)
  val activePlaylistSongs: StateFlow<List<SongEntity>> = _activePlaylist
    .flatMapLatest { playlist ->
      if (playlist != null) repository.getSongsForPlaylist(playlist.id)
      else flowOf(emptyList())
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val filteredSongs: StateFlow<List<SongEntity>> = combine(
    allSongs,
    _searchQuery,
    _sortOrder
  ) { songs, query, sort ->
    val filtered = if (query.isBlank()) {
      songs
    } else {
      songs.filter {
        it.title.contains(query, ignoreCase = true) ||
          it.artist.contains(query, ignoreCase = true) ||
          it.album.contains(query, ignoreCase = true)
      }
    }
    when (sort) {
      SortOrder.TITLE_ASC -> filtered.sortedBy { it.title.lowercase() }
      SortOrder.ARTIST_ASC -> filtered.sortedBy { it.artist.lowercase() }
      SortOrder.DATE_ADDED_DESC -> filtered.sortedByDescending { it.dateAdded }
      SortOrder.DURATION_DESC -> filtered.sortedByDescending { it.durationMs }
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _showNowPlaying = MutableStateFlow(false)
  val showNowPlaying: StateFlow<Boolean> = _showNowPlaying.asStateFlow()

  private val _activeDialog = MutableStateFlow<ActiveDialog?>(null)
  val activeDialog: StateFlow<ActiveDialog?> = _activeDialog.asStateFlow()

  private val _cacheSizeBytes = MutableStateFlow(0L)
  val cacheSizeBytes: StateFlow<Long> = _cacheSizeBytes.asStateFlow()

  private val _snackMessage = MutableStateFlow<String?>(null)
  val snackMessage: StateFlow<String?> = _snackMessage.asStateFlow()

  init {
    updateCacheSize()
  }

  fun updateSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setSortOrder(order: SortOrder) {
    _sortOrder.value = order
  }

  fun setLibraryTab(tab: LibraryTab) {
    _libraryTab.value = tab
  }

  fun openPlaylist(playlist: PlaylistEntity) {
    _activePlaylist.value = playlist
  }

  fun closePlaylist() {
    _activePlaylist.value = null
  }

  fun showNowPlayingScreen(show: Boolean) {
    _showNowPlaying.value = show
  }

  fun openDialog(dialog: ActiveDialog) {
    if (dialog is ActiveDialog.CleanStorage) {
      updateCacheSize()
    }
    _activeDialog.value = dialog
  }

  fun dismissDialog() {
    _activeDialog.value = null
  }

  fun clearSnackMessage() {
    _snackMessage.value = null
  }

  fun showMessage(msg: String) {
    _snackMessage.value = msg
  }

  fun updateCacheSize() {
    _cacheSizeBytes.value = repository.getCacheSizeBytes()
  }

  // Playback Operations
  fun playSong(song: SongEntity, fromList: List<SongEntity>? = null) {
    val queue = fromList ?: allSongs.value
    val index = queue.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
    controller.playQueue(queue, index)
    viewModelScope.launch {
      repository.updateQueue(queue)
    }
  }

  fun playQueue(songs: List<SongEntity>, startIndex: Int = 0) {
    controller.playQueue(songs, startIndex)
    viewModelScope.launch {
      repository.updateQueue(songs)
    }
  }

  fun togglePlayPause() = controller.togglePlayPause()
  fun skipNext() = controller.skipNext()
  fun skipPrevious() = controller.skipPrevious()
  fun seekTo(ms: Long) = controller.seekTo(ms)
  fun toggleShuffle() = controller.toggleShuffle()
  fun toggleRepeat() = controller.toggleRepeat()
  fun setSleepTimer(minutes: Int) = controller.setSleepTimer(minutes)
  fun cancelSleepTimer() = controller.cancelSleepTimer()
  fun removeQueueItemAt(index: Int) = controller.removeQueueItemAt(index)

  fun toggleFavorite(song: SongEntity) {
    viewModelScope.launch {
      repository.toggleFavorite(song)
    }
  }

  fun updateSongMetadata(songId: Long, title: String, artist: String, album: String) {
    viewModelScope.launch {
      repository.updateSongMetadata(songId, title, artist, album)
      showMessage("Updated \"$title\"")
    }
  }

  fun deleteSong(song: SongEntity) {
    viewModelScope.launch {
      repository.deleteSong(song)
      showMessage("Removed from library")
    }
  }

  fun createPlaylist(name: String) {
    viewModelScope.launch {
      repository.createPlaylist(name)
      showMessage("Created playlist \"$name\"")
    }
  }

  fun deletePlaylist(playlist: PlaylistEntity) {
    viewModelScope.launch {
      repository.deletePlaylist(playlist)
      if (_activePlaylist.value?.id == playlist.id) {
        _activePlaylist.value = null
      }
      showMessage("Deleted playlist")
    }
  }

  fun addSongToPlaylist(playlistId: Long, songId: Long) {
    viewModelScope.launch {
      repository.addSongToPlaylist(playlistId, songId)
      showMessage("Added to playlist")
    }
  }

  fun createAndAddSongToPlaylist(playlistName: String, songId: Long) {
    viewModelScope.launch {
      val playlistId = repository.createPlaylist(playlistName)
      repository.addSongToPlaylist(playlistId, songId)
      showMessage("Added to new playlist \"$playlistName\"")
    }
  }

  fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
    viewModelScope.launch {
      repository.removeSongFromPlaylist(playlistId, songId)
    }
  }

  fun scanDeviceSongs() {
    viewModelScope.launch {
      val count = repository.scanDeviceLibrary()
      if (count > 0) {
        showMessage("Found $count songs on device")
      } else {
        showMessage("No new audio files found in device storage")
      }
    }
  }

  fun importAudioUri(uri: Uri) {
    viewModelScope.launch {
      val song = repository.importAudioUri(uri)
      if (song != null) {
        showMessage("Imported \"${song.title}\"")
        playSong(song)
      } else {
        showMessage("Failed to import audio file")
      }
    }
  }

  fun addDemoPack() {
    viewModelScope.launch {
      val count = repository.addDemoPack()
      showMessage("Loaded $count demo tracks")
    }
  }

  fun cleanStorageCache() {
    viewModelScope.launch {
      val freed = repository.cleanStorageCache()
      updateCacheSize()
      showMessage("Freed ${com.example.ui.util.TimeUtils.formatFileSize(freed)} cache space")
    }
  }

  fun exportActivePlaylist(onResult: (String) -> Unit) {
    val playlist = _activePlaylist.value ?: return
    viewModelScope.launch {
      val text = repository.exportPlaylist(playlist.id)
      onResult(text)
    }
  }

  fun importPlaylistText(text: String) {
    viewModelScope.launch {
      repository.importPlaylistFromText(text)
      showMessage("Playlist imported successfully")
    }
  }
}

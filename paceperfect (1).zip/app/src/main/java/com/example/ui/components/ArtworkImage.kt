package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonRose
import com.example.ui.theme.VividCyan

@Composable
fun ArtworkImage(
  artworkUri: String?,
  title: String,
  modifier: Modifier = Modifier,
  cornerRadius: Dp = 12.dp,
  iconSize: Dp = 24.dp
) {
  // Generate deterministic gradient colors from title string
  val hash = title.hashCode()
  val gradientColors = when (Math.abs(hash) % 4) {
    0 -> listOf(NeonRose, ElectricViolet)
    1 -> listOf(ElectricViolet, VividCyan)
    2 -> listOf(VividCyan, NeonRose)
    else -> listOf(ElectricViolet, Color(0xFF6366F1))
  }

  val shape = RoundedCornerShape(cornerRadius)

  Box(
    modifier = modifier
      .clip(shape)
      .background(Brush.linearGradient(gradientColors)),
    contentAlignment = Alignment.Center
  ) {
    if (!artworkUri.isNullOrEmpty()) {
      AsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
          .data(artworkUri)
          .crossfade(true)
          .build(),
        contentDescription = "Artwork for $title",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
      )
    } else {
      Icon(
        imageVector = Icons.Default.MusicNote,
        contentDescription = null,
        tint = Color.White.copy(alpha = 0.85f),
        modifier = Modifier.size(iconSize)
      )
    }
  }
}

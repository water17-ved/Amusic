package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.PlaylistEntity
import com.example.data.model.SongEntity
import com.example.ui.components.ArtworkImage
import com.example.ui.util.TimeUtils

@Composable
fun PlaylistsScreen(
  playlists: List<PlaylistEntity>,
  activePlaylist: PlaylistEntity?,
  activePlaylistSongs: List<SongEntity>,
  onOpenPlaylist: (PlaylistEntity) -> Unit,
  onClosePlaylist: () -> Unit,
  onCreatePlaylist: (String) -> Unit,
  onDeletePlaylist: (PlaylistEntity) -> Unit,
  onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
  onPlayAll: (List<SongEntity>) -> Unit,
  onRemoveSongFromPlaylist: (playlistId: Long, songId: Long) -> Unit,
  onExportPlaylist: (playlistId: Long) -> Unit,
  onImportPlaylist: (String) -> Unit
) {
  var showCreateDialog by remember { mutableStateOf(false) }
  var newPlaylistName by remember { mutableStateOf("") }
  var showImportDialog by remember { mutableStateOf(false) }
  var importText by remember { mutableStateOf("") }

  if (activePlaylist != null) {
    // Playlist Details View
    PlaylistDetailView(
      playlist = activePlaylist,
      songs = activePlaylistSongs,
      onBack = onClosePlaylist,
      onPlayAll = { onPlayAll(activePlaylistSongs) },
      onShuffle = { onPlayAll(activePlaylistSongs.shuffled()) },
      onPlaySong = { song -> onPlaySong(song, activePlaylistSongs) },
      onRemoveSong = { songId -> onRemoveSongFromPlaylist(activePlaylist.id, songId) },
      onDeletePlaylist = {
        onDeletePlaylist(activePlaylist)
        onClosePlaylist()
      },
      onExport = { onExportPlaylist(activePlaylist.id) }
    )
  } else {
    // Playlists Overview
    Scaffold(
      floatingActionButton = {
        FloatingActionButton(
          onClick = { showCreateDialog = true },
          containerColor = MaterialTheme.colorScheme.primary,
          contentColor = MaterialTheme.colorScheme.onPrimary,
          modifier = Modifier.padding(bottom = 70.dp)
        ) {
          Icon(Icons.Default.Add, contentDescription = "Create Playlist")
        }
      }
    ) { innerPadding ->
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Your Playlists",
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
          )

          OutlinedButton(onClick = { showImportDialog = true }) {
            Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Import")
          }
        }

        if (playlists.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(
                imageVector = Icons.Default.QueueMusic,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
              )
              Spacer(modifier = Modifier.height(16.dp))
              Text(
                text = "No playlists created yet",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Tap the + button to create your first music mix.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(playlists) { playlist ->
              Card(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable { onOpenPlaylist(playlist) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                  containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  ArtworkImage(
                    artworkUri = null,
                    title = playlist.name,
                    modifier = Modifier.size(52.dp),
                    cornerRadius = 14.dp,
                    iconSize = 26.dp
                  )
                  Spacer(modifier = Modifier.width(16.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = playlist.name,
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                      text = "Tap to view tracks",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                  IconButton(onClick = { onDeletePlaylist(playlist) }) {
                    Icon(
                      imageVector = Icons.Default.Delete,
                      contentDescription = "Delete Playlist",
                      tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // Create Playlist Dialog
  if (showCreateDialog) {
    AlertDialog(
      onDismissRequest = { showCreateDialog = false },
      title = { Text("New Playlist") },
      text = {
        OutlinedTextField(
          value = newPlaylistName,
          onValueChange = { newPlaylistName = it },
          label = { Text("Playlist Title") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (newPlaylistName.isNotBlank()) {
              onCreatePlaylist(newPlaylistName.trim())
              newPlaylistName = ""
              showCreateDialog = false
            }
          },
          enabled = newPlaylistName.isNotBlank()
        ) {
          Text("Create")
        }
      },
      dismissButton = {
        TextButton(onClick = { showCreateDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  // Import Playlist Dialog
  if (showImportDialog) {
    AlertDialog(
      onDismissRequest = { showImportDialog = false },
      title = { Text("Import Playlist (M3U / JSON)") },
      text = {
        Column {
          Text(
            text = "Paste M3U playlist file content or JSON playlist data below:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = importText,
            onValueChange = { importText = it },
            placeholder = { Text("#EXTM3U\n#PLAYLIST: Chill Vibes\n...") },
            modifier = Modifier
              .fillMaxWidth()
              .height(150.dp)
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (importText.isNotBlank()) {
              onImportPlaylist(importText.trim())
              importText = ""
              showImportDialog = false
            }
          },
          enabled = importText.isNotBlank()
        ) {
          Text("Import")
        }
      },
      dismissButton = {
        TextButton(onClick = { showImportDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}

@Composable
fun PlaylistDetailView(
  playlist: PlaylistEntity,
  songs: List<SongEntity>,
  onBack: () -> Unit,
  onPlayAll: () -> Unit,
  onShuffle: () -> Unit,
  onPlaySong: (SongEntity) -> Unit,
  onRemoveSong: (songId: Long) -> Unit,
  onDeletePlaylist: () -> Unit,
  onExport: () -> Unit
) {
  Column(modifier = Modifier.fillMaxSize()) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
      }
      Spacer(modifier = Modifier.width(8.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = playlist.name,
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = "${songs.size} tracks",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
      IconButton(onClick = onExport) {
        Icon(Icons.Default.FileDownload, contentDescription = "Export M3U")
      }
      IconButton(onClick = onDeletePlaylist) {
        Icon(Icons.Default.Delete, contentDescription = "Delete Playlist", tint = MaterialTheme.colorScheme.error)
      }
    }

    // Action Buttons
    if (songs.isNotEmpty()) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Button(
          onClick = onPlayAll,
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text("Play All")
        }

        OutlinedButton(
          onClick = onShuffle,
          modifier = Modifier.weight(1f)
        ) {
          Icon(Icons.Default.Shuffle, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text("Shuffle")
        }
      }
    }

    if (songs.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "This playlist is empty. Add songs from your Library or Home screen.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 110.dp)
      ) {
        items(songs) { song ->
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onPlaySong(song) }
              .padding(vertical = 4.dp),
            color = MaterialTheme.colorScheme.surface
          ) {
            Row(
              modifier = Modifier.padding(vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              ArtworkImage(
                artworkUri = song.artworkUri,
                title = song.title,
                modifier = Modifier.size(44.dp),
                cornerRadius = 8.dp,
                iconSize = 20.dp
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = song.title,
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Text(
                  text = "${song.artist} • ${TimeUtils.formatMs(song.durationMs)}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }
              IconButton(onClick = { onRemoveSong(song.id) }) {
                Icon(
                  imageVector = Icons.Default.RemoveCircleOutline,
                  contentDescription = "Remove from playlist",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }
    }
  }
}

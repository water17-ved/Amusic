package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.SongEntity
import com.example.ui.components.ArtworkImage
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonRose
import com.example.ui.theme.VividCyan
import com.example.ui.util.TimeUtils

@Composable
fun HomeScreen(
  songs: List<SongEntity>,
  favorites: List<SongEntity>,
  playlistsCount: Int,
  searchQuery: String,
  onSearchChange: (String) -> Unit,
  onSongClick: (SongEntity, List<SongEntity>) -> Unit,
  onShuffleAll: () -> Unit,
  onToggleFavorite: (SongEntity) -> Unit,
  onAddToPlaylist: (SongEntity) -> Unit,
  onEditMetadata: (SongEntity) -> Unit,
  onRemoveSong: (SongEntity) -> Unit,
  onImportClick: () -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(bottom = 110.dp)
  ) {
    // Search Bar
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp)
      ) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = onSearchChange,
          leadingIcon = {
            Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary)
          },
          placeholder = { Text("Search songs, artists, albums...") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(24.dp),
          singleLine = true
        )
      }
    }

    // Hero Banner Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(
              Brush.linearGradient(
                colors = listOf(
                  NeonRose.copy(alpha = 0.85f),
                  ElectricViolet.copy(alpha = 0.95f),
                  VividCyan.copy(alpha = 0.8f)
                )
              )
            )
            .padding(20.dp)
        ) {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(Color.White.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.MusicNote,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = "PULSE AUDIO",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White.copy(alpha = 0.9f)
              )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "Hi-Fi Local Sound",
              style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
              color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "${songs.size} Tracks • ${favorites.size} Favorites • $playlistsCount Playlists",
              style = MaterialTheme.typography.bodyMedium,
              color = Color.White.copy(alpha = 0.85f)
            )
            Spacer(modifier = Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              Button(
                onClick = onShuffleAll,
                colors = ButtonDefaults.buttonColors(
                  containerColor = Color.White,
                  contentColor = Color(0xFF1E1B4B)
                ),
                shape = RoundedCornerShape(14.dp)
              ) {
                Icon(Icons.Default.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Shuffle All", fontWeight = FontWeight.SemiBold)
              }

              Button(
                onClick = onImportClick,
                colors = ButtonDefaults.buttonColors(
                  containerColor = Color.White.copy(alpha = 0.25f),
                  contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp)
              ) {
                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Track", fontWeight = FontWeight.SemiBold)
              }
            }
          }
        }
      }
    }

    // Recently Added Section
    if (songs.isNotEmpty()) {
      item {
        Column(modifier = Modifier.padding(top = 16.dp)) {
          Text(
            text = "Featured Tracks",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
          )

          LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            items(songs.take(8)) { song ->
              FeaturedSongCard(
                song = song,
                onClick = { onSongClick(song, songs) }
              )
            }
          }
        }
      }
    }

    // All / Favorites Quick List
    val displayList = if (favorites.isNotEmpty()) favorites else songs
    val sectionTitle = if (favorites.isNotEmpty()) "Favorite Tracks" else "Quick Play"

    item {
      Spacer(modifier = Modifier.height(20.dp))
      Text(
        text = sectionTitle,
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
      )
    }

    if (displayList.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "No tracks yet. Tap Add Track to import audio.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    } else {
      items(displayList.take(15)) { song ->
        SongListItem(
          song = song,
          onClick = { onSongClick(song, displayList) },
          onToggleFavorite = { onToggleFavorite(song) },
          onAddToPlaylist = { onAddToPlaylist(song) },
          onEditMetadata = { onEditMetadata(song) },
          onRemove = { onRemoveSong(song) }
        )
      }
    }
  }
}

@Composable
fun FeaturedSongCard(
  song: SongEntity,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .width(140.dp)
      .clickable { onClick() },
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Box(modifier = Modifier.size(120.dp)) {
        ArtworkImage(
          artworkUri = song.artworkUri,
          title = song.title,
          modifier = Modifier.fillMaxSize(),
          cornerRadius = 12.dp,
          iconSize = 36.dp
        )
        Box(
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(6.dp)
            .size(32.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = "Play",
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(20.dp)
          )
        }
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = song.title,
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
      Text(
        text = song.artist,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
    }
  }
}

@Composable
fun SongListItem(
  song: SongEntity,
  onClick: () -> Unit,
  onToggleFavorite: () -> Unit,
  onAddToPlaylist: () -> Unit,
  onEditMetadata: () -> Unit,
  onRemove: () -> Unit
) {
  var showMenu by remember { mutableStateOf(false) }

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .padding(horizontal = 16.dp, vertical = 4.dp),
    color = Color.Transparent
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      ArtworkImage(
        artworkUri = song.artworkUri,
        title = song.title,
        modifier = Modifier.size(48.dp),
        cornerRadius = 10.dp,
        iconSize = 22.dp
      )

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = song.title,
          style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "${song.artist} • ${TimeUtils.formatMs(song.durationMs)}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      IconButton(onClick = onToggleFavorite) {
        Icon(
          imageVector = if (song.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
          contentDescription = "Favorite",
          tint = if (song.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Box {
        IconButton(onClick = { showMenu = true }) {
          Icon(
            imageVector = Icons.Default.MoreVert,
            contentDescription = "Options",
            tint = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        DropdownMenu(
          expanded = showMenu,
          onDismissRequest = { showMenu = false }
        ) {
          DropdownMenuItem(
            text = { Text("Add to Playlist") },
            onClick = {
              showMenu = false
              onAddToPlaylist()
            }
          )
          DropdownMenuItem(
            text = { Text("Edit Details") },
            onClick = {
              showMenu = false
              onEditMetadata()
            }
          )
          DropdownMenuItem(
            text = { Text("Remove from Library") },
            onClick = {
              showMenu = false
              onRemove()
            }
          )
        }
      }
    }
  }
}

package com.example.ui.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.util.TimeUtils

@Composable
fun SleepTimerDialog(
  remainingSec: Long?,
  onSetTimer: (minutes: Int) -> Unit,
  onCancelTimer: () -> Unit,
  onDismiss: () -> Unit
) {
  val presetOptions = listOf(15, 30, 45, 60)

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.Bedtime,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary
      )
    },
    title = {
      Text(text = "Sleep Timer")
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        if (remainingSec != null && remainingSec > 0) {
          Text(
            text = "Active Timer: ${TimeUtils.formatMs(remainingSec * 1000L)} remaining",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.height(12.dp))
          Button(
            onClick = {
              onCancelTimer()
              onDismiss()
            },
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.errorContainer,
              contentColor = MaterialTheme.colorScheme.onErrorContainer
            ),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("Turn Off Sleep Timer")
          }
          Spacer(modifier = Modifier.height(16.dp))
        }

        Text(
          text = "Select time until music automatically pauses:",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          presetOptions.take(2).forEach { mins ->
            OutlinedButton(
              onClick = {
                onSetTimer(mins)
                onDismiss()
              },
              modifier = Modifier.weight(1f)
            ) {
              Text("$mins min")
            }
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          presetOptions.drop(2).forEach { mins ->
            OutlinedButton(
              onClick = {
                onSetTimer(mins)
                onDismiss()
              },
              modifier = Modifier.weight(1f)
            ) {
              Text("$mins min")
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("Close")
      }
    }
  )
}

package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.util.TimeUtils

@Composable
fun SettingsScreen(
  cacheSizeBytes: Long,
  sleepTimerRemainingSec: Long?,
  onScanDevice: () -> Unit,
  onAddDemoPack: () -> Unit,
  onOpenSleepTimer: () -> Unit,
  onOpenCleanStorage: () -> Unit
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 110.dp)
  ) {
    item {
      Text(
        text = "Settings",
        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
        modifier = Modifier.padding(bottom = 16.dp)
      )
    }

    item {
      Text(
        text = "MUSIC LIBRARY",
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(vertical = 8.dp)
      )
    }

    item {
      SettingsItemCard(
        title = "Scan Device Storage",
        subtitle = "Search device memory for audio files & update library",
        icon = Icons.Default.Refresh,
        onClick = onScanDevice
      )
    }

    item {
      Spacer(modifier = Modifier.height(8.dp))
      SettingsItemCard(
        title = "Load Sample Demo Tracks",
        subtitle = "Add 5 synthesised offline demo songs (Synthwave, Chill, Lo-Fi)",
        icon = Icons.Default.FolderSpecial,
        onClick = onAddDemoPack
      )
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
      Text(
        text = "PLAYBACK & STORAGE",
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(vertical = 8.dp)
      )
    }

    item {
      val sleepSubtitle = if (sleepTimerRemainingSec != null) {
        "Active: ${TimeUtils.formatMs(sleepTimerRemainingSec * 1000L)} remaining"
      } else {
        "Set automatic music shutdown timer"
      }
      SettingsItemCard(
        title = "Sleep Timer",
        subtitle = sleepSubtitle,
        icon = Icons.Default.Bedtime,
        onClick = onOpenSleepTimer
      )
    }

    item {
      Spacer(modifier = Modifier.height(8.dp))
      SettingsItemCard(
        title = "Clean Storage Cache",
        subtitle = "Cached artwork & temp files: ${TimeUtils.formatFileSize(cacheSizeBytes)}",
        icon = Icons.Default.CleaningServices,
        onClick = onOpenCleanStorage
      )
    }

    item {
      Spacer(modifier = Modifier.height(16.dp))
      Text(
        text = "ABOUT",
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(vertical = 8.dp)
      )
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.LibraryMusic,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = "Music Player v1.0",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Modern offline audio player built with Jetpack Compose, Room local storage, MediaStore indexing, ID3 metadata parsing, and background playback.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}

@Composable
fun SettingsItemCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() },
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    )
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.size(44.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.size(24.dp)
          )
        }
      }
      Spacer(modifier = Modifier.width(16.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

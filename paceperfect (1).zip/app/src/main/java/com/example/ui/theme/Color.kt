package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Electric Violet / Fuchsia / Neon Rose
val NeonRose = Color(0xFFF43F5E)
val ElectricViolet = Color(0xFFA855F7)
val VividCyan = Color(0xFF06B6D4)
val AmberGlow = Color(0xFFF59E0B)

// Dark Theme Surfaces
val MusicDarkBackground = Color(0xFF0B0F19)
val MusicDarkSurface = Color(0xFF131B2E)
val MusicDarkSurfaceVariant = Color(0xFF1E293B)
val MusicDarkSurfaceCard = Color(0xFF182238)
val MusicDarkOnSurface = Color(0xFFF1F5F9)
val MusicDarkOnSurfaceVariant = Color(0xFF94A3B8)

// Light Theme Surfaces
val MusicLightBackground = Color(0xFFF8FAFC)
val MusicLightSurface = Color(0xFFFFFFFF)
val MusicLightSurfaceVariant = Color(0xFFE2E8F0)
val MusicLightOnSurface = Color(0xFF0F172A)
val MusicLightOnSurfaceVariant = Color(0xFF64748B)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

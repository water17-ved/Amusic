package com.example.playback

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.CountDownTimer
import androidx.core.content.ContextCompat
import com.example.data.model.SongEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class RepeatMode {
  OFF, ALL, ONE
}

data class PlaybackUiState(
  val currentSong: SongEntity? = null,
  val isPlaying: Boolean = false,
  val currentPositionMs: Long = 0L,
  val durationMs: Long = 0L,
  val isShuffle: Boolean = false,
  val repeatMode: RepeatMode = RepeatMode.OFF,
  val queue: List<SongEntity> = emptyList(),
  val currentIndex: Int = -1,
  val sleepTimerRemainingSec: Long? = null,
  val error: String? = null
)

class MusicPlaybackController private constructor(private val appContext: Context) {

  private val _uiState = MutableStateFlow(PlaybackUiState())
  val uiState: StateFlow<PlaybackUiState> = _uiState.asStateFlow()

  private var mediaPlayer: MediaPlayer? = null
  private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
  private var audioFocusRequest: AudioFocusRequest? = null

  private val scope = CoroutineScope(Dispatchers.Main + Job())
  private var progressTrackerJob: Job? = null
  private var sleepCountDownTimer: CountDownTimer? = null

  private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
    when (focusChange) {
      AudioManager.AUDIOFOCUS_LOSS -> pause()
      AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> pause()
      AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
        mediaPlayer?.setVolume(0.2f, 0.2f)
      }
      AudioManager.AUDIOFOCUS_GAIN -> {
        mediaPlayer?.setVolume(1.0f, 1.0f)
        if (!_uiState.value.isPlaying && _uiState.value.currentSong != null) {
          resume()
        }
      }
    }
  }

  companion object {
    @Volatile
    private var INSTANCE: MusicPlaybackController? = null

    fun getInstance(context: Context): MusicPlaybackController {
      return INSTANCE ?: synchronized(this) {
        val instance = MusicPlaybackController(context.applicationContext)
        INSTANCE = instance
        instance
      }
    }
  }

  private fun requestAudioFocus(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val attributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

      val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
        .setAudioAttributes(attributes)
        .setAcceptsDelayedFocusGain(true)
        .setOnAudioFocusChangeListener(focusChangeListener)
        .build()

      audioFocusRequest = request
      audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    } else {
      @Suppress("DEPRECATION")
      audioManager.requestAudioFocus(
        focusChangeListener,
        AudioManager.STREAM_MUSIC,
        AudioManager.AUDIOFOCUS_GAIN
      ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }
  }

  private fun abandonAudioFocus() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
    } else {
      @Suppress("DEPRECATION")
      audioManager.abandonAudioFocus(focusChangeListener)
    }
  }

  fun playQueue(songs: List<SongEntity>, startIndex: Int = 0) {
    if (songs.isEmpty()) return
    val clampedIndex = startIndex.coerceIn(0, songs.lastIndex)
    _uiState.value = _uiState.value.copy(
      queue = songs,
      currentIndex = clampedIndex
    )
    playCurrentSong()
  }

  fun playSong(song: SongEntity) {
    val existingIndex = _uiState.value.queue.indexOfFirst { it.id == song.id }
    if (existingIndex >= 0) {
      _uiState.value = _uiState.value.copy(currentIndex = existingIndex)
      playCurrentSong()
    } else {
      val newQueue = _uiState.value.queue + song
      _uiState.value = _uiState.value.copy(
        queue = newQueue,
        currentIndex = newQueue.lastIndex
      )
      playCurrentSong()
    }
  }

  private fun playCurrentSong() {
    val state = _uiState.value
    if (state.currentIndex !in state.queue.indices) return
    val song = state.queue[state.currentIndex]

    releasePlayer()
    if (!requestAudioFocus()) return

    try {
      val player = MediaPlayer().apply {
        setAudioAttributes(
          AudioAttributes.Builder()
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .build()
        )
        setDataSource(appContext, Uri.parse(song.uriString))
        setOnPreparedListener { mp ->
          mp.start()
          _uiState.value = _uiState.value.copy(
            currentSong = song,
            isPlaying = true,
            currentPositionMs = 0L,
            durationMs = mp.duration.toLong().coerceAtLeast(song.durationMs),
            error = null
          )
          startProgressTracker()
          notifyService(PlaybackService.ACTION_UPDATE)
        }
        setOnCompletionListener {
          handleSongCompletion()
        }
        setOnErrorListener { _, what, extra ->
          _uiState.value = _uiState.value.copy(
            isPlaying = false,
            error = "Playback error ($what, $extra)"
          )
          false
        }
        prepareAsync()
      }
      mediaPlayer = player
    } catch (e: Exception) {
      _uiState.value = _uiState.value.copy(
        isPlaying = false,
        error = "Failed to load song: ${e.message}"
      )
    }
  }

  private fun handleSongCompletion() {
    val state = _uiState.value
    when (state.repeatMode) {
      RepeatMode.ONE -> {
        mediaPlayer?.seekTo(0)
        mediaPlayer?.start()
        _uiState.value = _uiState.value.copy(isPlaying = true, currentPositionMs = 0L)
      }
      RepeatMode.ALL -> {
        skipNext()
      }
      RepeatMode.OFF -> {
        if (state.currentIndex < state.queue.lastIndex) {
          skipNext()
        } else {
          pause()
          seekTo(0L)
        }
      }
    }
  }

  fun togglePlayPause() {
    if (_uiState.value.isPlaying) {
      pause()
    } else {
      resume()
    }
  }

  fun resume() {
    val player = mediaPlayer
    if (player != null && !player.isPlaying) {
      if (requestAudioFocus()) {
        player.start()
        _uiState.value = _uiState.value.copy(isPlaying = true)
        startProgressTracker()
        notifyService(PlaybackService.ACTION_UPDATE)
      }
    } else if (_uiState.value.currentSong != null) {
      playCurrentSong()
    } else if (_uiState.value.queue.isNotEmpty()) {
      _uiState.value = _uiState.value.copy(currentIndex = 0)
      playCurrentSong()
    }
  }

  fun pause() {
    mediaPlayer?.let {
      if (it.isPlaying) {
        it.pause()
      }
    }
    _uiState.value = _uiState.value.copy(isPlaying = false)
    progressTrackerJob?.cancel()
    notifyService(PlaybackService.ACTION_UPDATE)
  }

  fun seekTo(positionMs: Long) {
    mediaPlayer?.let {
      val target = positionMs.toInt().coerceIn(0, it.duration)
      it.seekTo(target)
      _uiState.value = _uiState.value.copy(currentPositionMs = target.toLong())
    }
  }

  fun skipNext() {
    val state = _uiState.value
    if (state.queue.isEmpty()) return

    val nextIndex = if (state.isShuffle) {
      val available = state.queue.indices.filter { it != state.currentIndex }
      if (available.isNotEmpty()) available.random() else 0
    } else {
      (state.currentIndex + 1) % state.queue.size
    }

    _uiState.value = state.copy(currentIndex = nextIndex)
    playCurrentSong()
  }

  fun skipPrevious() {
    val state = _uiState.value
    if (state.queue.isEmpty()) return

    // If more than 3 seconds in, restart the song
    if (state.currentPositionMs > 3000L) {
      seekTo(0L)
      return
    }

    val prevIndex = if (state.currentIndex > 0) {
      state.currentIndex - 1
    } else {
      state.queue.lastIndex
    }

    _uiState.value = state.copy(currentIndex = prevIndex)
    playCurrentSong()
  }

  fun toggleShuffle() {
    _uiState.value = _uiState.value.copy(isShuffle = !_uiState.value.isShuffle)
  }

  fun toggleRepeat() {
    val nextMode = when (_uiState.value.repeatMode) {
      RepeatMode.OFF -> RepeatMode.ALL
      RepeatMode.ALL -> RepeatMode.ONE
      RepeatMode.ONE -> RepeatMode.OFF
    }
    _uiState.value = _uiState.value.copy(repeatMode = nextMode)
  }

  fun setSleepTimer(minutes: Int) {
    sleepCountDownTimer?.cancel()
    if (minutes <= 0) {
      _uiState.value = _uiState.value.copy(sleepTimerRemainingSec = null)
      return
    }

    val totalMillis = minutes * 60 * 1000L
    sleepCountDownTimer = object : CountDownTimer(totalMillis, 1000L) {
      override fun onTick(millisUntilFinished: Long) {
        _uiState.value = _uiState.value.copy(
          sleepTimerRemainingSec = millisUntilFinished / 1000L
        )
      }

      override fun onFinish() {
        pause()
        _uiState.value = _uiState.value.copy(sleepTimerRemainingSec = null)
      }
    }.start()
  }

  fun cancelSleepTimer() {
    sleepCountDownTimer?.cancel()
    _uiState.value = _uiState.value.copy(sleepTimerRemainingSec = null)
  }

  fun removeQueueItemAt(index: Int) {
    val state = _uiState.value
    if (index !in state.queue.indices) return
    val newQueue = state.queue.toMutableList().apply { removeAt(index) }
    var newCurrent = state.currentIndex
    if (index < state.currentIndex) {
      newCurrent -= 1
    } else if (index == state.currentIndex) {
      if (newQueue.isEmpty()) {
        pause()
        releasePlayer()
        _uiState.value = PlaybackUiState()
        return
      } else {
        newCurrent = newCurrent.coerceAtMost(newQueue.lastIndex)
      }
    }
    _uiState.value = state.copy(queue = newQueue, currentIndex = newCurrent)
  }

  private fun startProgressTracker() {
    progressTrackerJob?.cancel()
    progressTrackerJob = scope.launch {
      while (isActive && mediaPlayer?.isPlaying == true) {
        val pos = mediaPlayer?.currentPosition?.toLong() ?: 0L
        _uiState.value = _uiState.value.copy(currentPositionMs = pos)
        delay(500)
      }
    }
  }

  private fun notifyService(action: String) {
    try {
      val intent = Intent(appContext, PlaybackService::class.java).apply {
        this.action = action
      }
      ContextCompat.startForegroundService(appContext, intent)
    } catch (e: Exception) {
      // Background start restrictions on Android 12+ if app is in background
    }
  }

  private fun releasePlayer() {
    progressTrackerJob?.cancel()
    mediaPlayer?.let {
      try {
        if (it.isPlaying) it.stop()
        it.release()
      } catch (ignored: Exception) {}
    }
    mediaPlayer = null
  }

  fun stop() {
    pause()
    releasePlayer()
    abandonAudioFocus()
    cancelSleepTimer()
    notifyService(PlaybackService.ACTION_STOP)
  }
}

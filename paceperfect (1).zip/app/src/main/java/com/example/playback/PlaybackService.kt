package com.example.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity

class PlaybackService : Service() {

  companion object {
    const val CHANNEL_ID = "playback_channel_id"
    const val NOTIFICATION_ID = 101

    const val ACTION_UPDATE = "com.example.playback.ACTION_UPDATE"
    const val ACTION_PLAY_PAUSE = "com.example.playback.ACTION_PLAY_PAUSE"
    const val ACTION_NEXT = "com.example.playback.ACTION_NEXT"
    const val ACTION_PREV = "com.example.playback.ACTION_PREV"
    const val ACTION_STOP = "com.example.playback.ACTION_STOP"
  }

  private lateinit var controller: MusicPlaybackController

  override fun onCreate() {
    super.onCreate()
    controller = MusicPlaybackController.getInstance(this)
    createNotificationChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_PLAY_PAUSE -> controller.togglePlayPause()
      ACTION_NEXT -> controller.skipNext()
      ACTION_PREV -> controller.skipPrevious()
      ACTION_STOP -> {
        controller.stop()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        return START_NOT_STICKY
      }
      ACTION_UPDATE -> updateNotification()
      else -> updateNotification()
    }
    return START_STICKY
  }

  private fun updateNotification() {
    val state = controller.uiState.value
    val song = state.currentSong

    if (song == null) {
      stopForeground(STOP_FOREGROUND_REMOVE)
      return
    }

    val activityIntent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
    }
    val contentPendingIntent = PendingIntent.getActivity(
      this,
      0,
      activityIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val playPauseIntent = Intent(this, PlaybackService::class.java).apply {
      action = ACTION_PLAY_PAUSE
    }
    val playPausePendingIntent = PendingIntent.getService(
      this,
      1,
      playPauseIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val prevIntent = Intent(this, PlaybackService::class.java).apply {
      action = ACTION_PREV
    }
    val prevPendingIntent = PendingIntent.getService(
      this,
      2,
      prevIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val nextIntent = Intent(this, PlaybackService::class.java).apply {
      action = ACTION_NEXT
    }
    val nextPendingIntent = PendingIntent.getService(
      this,
      3,
      nextIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val stopIntent = Intent(this, PlaybackService::class.java).apply {
      action = ACTION_STOP
    }
    val stopPendingIntent = PendingIntent.getService(
      this,
      4,
      stopIntent,
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    val playPauseIcon = if (state.isPlaying) {
      android.R.drawable.ic_media_pause
    } else {
      android.R.drawable.ic_media_play
    }
    val playPauseTitle = if (state.isPlaying) "Pause" else "Play"

    val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle(song.title)
      .setContentText("${song.artist} • ${song.album}")
      .setSmallIcon(android.R.drawable.ic_media_play)
      .setContentIntent(contentPendingIntent)
      .setOngoing(state.isPlaying)
      .setSilent(true)
      .addAction(android.R.drawable.ic_media_previous, "Previous", prevPendingIntent)
      .addAction(playPauseIcon, playPauseTitle, playPausePendingIntent)
      .addAction(android.R.drawable.ic_media_next, "Next", nextPendingIntent)
      .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
      .build()

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      ServiceCompat.startForeground(
        this,
        NOTIFICATION_ID,
        notification,
        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
      )
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "Music Playback",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Controls and status for active music playback"
        setShowBadge(false)
      }
      val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      manager.createNotificationChannel(channel)
    }
  }

  override fun onBind(intent: Intent?): IBinder? = null
}

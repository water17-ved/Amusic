package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ActiveDialog
import com.example.ui.MusicViewModel
import com.example.ui.components.MiniPlayer
import com.example.ui.dialogs.AddToPlaylistDialog
import com.example.ui.dialogs.CleanStorageDialog
import com.example.ui.dialogs.EditMetadataDialog
import com.example.ui.dialogs.RemoveFromLibraryDialog
import com.example.ui.dialogs.SleepTimerDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.NowPlayingScreen
import com.example.ui.screens.PlaylistsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        MusicAppRoot()
      }
    }
  }
}

@Composable
fun MusicAppRoot(vm: MusicViewModel = viewModel()) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }

  val playbackState by vm.playbackState.collectAsStateWithLifecycle()
  val allSongs by vm.allSongs.collectAsStateWithLifecycle()
  val favoriteSongs by vm.favoriteSongs.collectAsStateWithLifecycle()
  val playlists by vm.playlists.collectAsStateWithLifecycle()
  val filteredSongs by vm.filteredSongs.collectAsStateWithLifecycle()
  val searchQuery by vm.searchQuery.collectAsStateWithLifecycle()
  val sortOrder by vm.sortOrder.collectAsStateWithLifecycle()
  val libraryTab by vm.libraryTab.collectAsStateWithLifecycle()
  val activePlaylist by vm.activePlaylist.collectAsStateWithLifecycle()
  val activePlaylistSongs by vm.activePlaylistSongs.collectAsStateWithLifecycle()
  val showNowPlaying by vm.showNowPlaying.collectAsStateWithLifecycle()
  val activeDialog by vm.activeDialog.collectAsStateWithLifecycle()
  val cacheSize by vm.cacheSizeBytes.collectAsStateWithLifecycle()
  val snackMessage by vm.snackMessage.collectAsStateWithLifecycle()

  var selectedNavIndex by remember { mutableIntStateOf(0) }

  // Audio picker launcher for importing tracks
  val audioPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri ->
    if (uri != null) {
      vm.importAudioUri(uri)
    }
  }

  // Permission launcher
  val permissionToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
    Manifest.permission.READ_MEDIA_AUDIO
  } else {
    Manifest.permission.READ_EXTERNAL_STORAGE
  }

  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    if (isGranted) {
      vm.scanDeviceSongs()
    } else {
      vm.showMessage("Storage permission denied. You can still import songs manually.")
    }
  }

  LaunchedEffect(snackMessage) {
    snackMessage?.let {
      snackbarHostState.showSnackbar(it)
      vm.clearSnackMessage()
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      snackbarHost = { SnackbarHost(snackbarHostState) },
      bottomBar = {
        Column {
          // Persistent Mini Player above NavigationBar
          AnimatedVisibility(
            visible = playbackState.currentSong != null && !showNowPlaying,
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
          ) {
            MiniPlayer(
              playbackState = playbackState,
              onPlayPauseClick = { vm.togglePlayPause() },
              onSkipNextClick = { vm.skipNext() },
              onClick = { vm.showNowPlayingScreen(true) }
            )
          }

          NavigationBar {
            NavigationBarItem(
              selected = selectedNavIndex == 0,
              onClick = { selectedNavIndex = 0 },
              icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
              label = { Text("Home") }
            )
            NavigationBarItem(
              selected = selectedNavIndex == 1,
              onClick = { selectedNavIndex = 1 },
              icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Library") },
              label = { Text("Library") }
            )
            NavigationBarItem(
              selected = selectedNavIndex == 2,
              onClick = { selectedNavIndex = 2 },
              icon = { Icon(Icons.Default.QueueMusic, contentDescription = "Playlists") },
              label = { Text("Playlists") }
            )
            NavigationBarItem(
              selected = selectedNavIndex == 3,
              onClick = { selectedNavIndex = 3 },
              icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
              label = { Text("Settings") }
            )
          }
        }
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        when (selectedNavIndex) {
          0 -> HomeScreen(
            songs = allSongs,
            favorites = favoriteSongs,
            playlistsCount = playlists.size,
            searchQuery = searchQuery,
            onSearchChange = { vm.updateSearchQuery(it) },
            onSongClick = { song, list -> vm.playSong(song, list) },
            onShuffleAll = {
              if (allSongs.isNotEmpty()) {
                vm.playQueue(allSongs.shuffled(), 0)
              }
            },
            onToggleFavorite = { vm.toggleFavorite(it) },
            onAddToPlaylist = { vm.openDialog(ActiveDialog.AddToPlaylist(it)) },
            onEditMetadata = { vm.openDialog(ActiveDialog.EditMetadata(it)) },
            onRemoveSong = { vm.openDialog(ActiveDialog.RemoveFromLibrary(it)) },
            onImportClick = { audioPickerLauncher.launch("audio/*") }
          )

          1 -> LibraryScreen(
            songs = filteredSongs,
            currentTab = libraryTab,
            onTabChange = { vm.setLibraryTab(it) },
            sortOrder = sortOrder,
            onSortChange = { vm.setSortOrder(it) },
            searchQuery = searchQuery,
            onSearchChange = { vm.updateSearchQuery(it) },
            onSongClick = { song, list -> vm.playSong(song, list) },
            onToggleFavorite = { vm.toggleFavorite(it) },
            onAddToPlaylist = { vm.openDialog(ActiveDialog.AddToPlaylist(it)) },
            onEditMetadata = { vm.openDialog(ActiveDialog.EditMetadata(it)) },
            onRemoveSong = { vm.openDialog(ActiveDialog.RemoveFromLibrary(it)) }
          )

          2 -> PlaylistsScreen(
            playlists = playlists,
            activePlaylist = activePlaylist,
            activePlaylistSongs = activePlaylistSongs,
            onOpenPlaylist = { vm.openPlaylist(it) },
            onClosePlaylist = { vm.closePlaylist() },
            onCreatePlaylist = { vm.createPlaylist(it) },
            onDeletePlaylist = { vm.deletePlaylist(it) },
            onPlaySong = { song, list -> vm.playSong(song, list) },
            onPlayAll = { songs -> if (songs.isNotEmpty()) vm.playQueue(songs, 0) },
            onRemoveSongFromPlaylist = { pId, sId -> vm.removeSongFromPlaylist(pId, sId) },
            onExportPlaylist = { pId ->
              vm.exportActivePlaylist { text ->
                val sendIntent = Intent().apply {
                  action = Intent.ACTION_SEND
                  putExtra(Intent.EXTRA_TEXT, text)
                  type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, "Export Playlist"))
              }
            },
            onImportPlaylist = { text -> vm.importPlaylistText(text) }
          )

          3 -> SettingsScreen(
            cacheSizeBytes = cacheSize,
            sleepTimerRemainingSec = playbackState.sleepTimerRemainingSec,
            onScanDevice = {
              if (ContextCompat.checkSelfPermission(context, permissionToRequest) == PackageManager.PERMISSION_GRANTED) {
                vm.scanDeviceSongs()
              } else {
                permissionLauncher.launch(permissionToRequest)
              }
            },
            onAddDemoPack = { vm.addDemoPack() },
            onOpenSleepTimer = { vm.openDialog(ActiveDialog.SleepTimer) },
            onOpenCleanStorage = { vm.openDialog(ActiveDialog.CleanStorage) }
          )
        }
      }
    }

    // Full-Screen Now Playing View
    AnimatedVisibility(
      visible = showNowPlaying && playbackState.currentSong != null,
      enter = slideInVertically(initialOffsetY = { it }),
      exit = slideOutVertically(targetOffsetY = { it }),
      modifier = Modifier.fillMaxSize()
    ) {
      NowPlayingScreen(
        playbackState = playbackState,
        onDismiss = { vm.showNowPlayingScreen(false) },
        onPlayPause = { vm.togglePlayPause() },
        onSkipNext = { vm.skipNext() },
        onSkipPrevious = { vm.skipPrevious() },
        onSeekTo = { vm.seekTo(it) },
        onToggleShuffle = { vm.toggleShuffle() },
        onToggleRepeat = { vm.toggleRepeat() },
        onToggleFavorite = { playbackState.currentSong?.let { vm.toggleFavorite(it) } },
        onOpenSleepTimer = { vm.openDialog(ActiveDialog.SleepTimer) },
        onQueueItemClick = { index -> vm.playQueue(playbackState.queue, index) },
        onRemoveQueueItem = { index -> vm.removeQueueItemAt(index) }
      )
    }

    // Active Dialogs
    when (val dialog = activeDialog) {
      is ActiveDialog.AddToPlaylist -> {
        AddToPlaylistDialog(
          song = dialog.song,
          playlists = playlists,
          onAddToPlaylist = { playlistId -> vm.addSongToPlaylist(playlistId, dialog.song.id) },
          onCreateAndAddToPlaylist = { playlistName ->
            vm.createAndAddSongToPlaylist(playlistName, dialog.song.id)
          },
          onDismiss = { vm.dismissDialog() }
        )
      }

      is ActiveDialog.EditMetadata -> {
        EditMetadataDialog(
          song = dialog.song,
          onSave = { title, artist, album ->
            vm.updateSongMetadata(dialog.song.id, title, artist, album)
          },
          onDismiss = { vm.dismissDialog() }
        )
      }

      is ActiveDialog.RemoveFromLibrary -> {
        RemoveFromLibraryDialog(
          song = dialog.song,
          onConfirm = { vm.deleteSong(dialog.song) },
          onDismiss = { vm.dismissDialog() }
        )
      }

      is ActiveDialog.SleepTimer -> {
        SleepTimerDialog(
          remainingSec = playbackState.sleepTimerRemainingSec,
          onSetTimer = { minutes -> vm.setSleepTimer(minutes) },
          onCancelTimer = { vm.cancelSleepTimer() },
          onDismiss = { vm.dismissDialog() }
        )
      }

      is ActiveDialog.CleanStorage -> {
        CleanStorageDialog(
          cacheSizeBytes = cacheSize,
          onClean = { vm.cleanStorageCache() },
          onDismiss = { vm.dismissDialog() }
        )
      }

      else -> Unit
    }
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

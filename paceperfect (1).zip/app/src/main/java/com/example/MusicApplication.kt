package com.example

import android.app.Application
import com.example.data.MusicDatabase
import com.example.data.MusicFileManager
import com.example.data.MusicRepository
import com.example.playback.MusicPlaybackController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MusicApplication : Application() {

  lateinit var repository: MusicRepository
    private set

  lateinit var playbackController: MusicPlaybackController
    private set

  private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  override fun onCreate() {
    super.onCreate()

    val database = MusicDatabase.getInstance(this)
    val fileManager = MusicFileManager(this)
    repository = MusicRepository(
      songDao = database.songDao(),
      playlistDao = database.playlistDao(),
      queueDao = database.queueDao(),
      fileManager = fileManager
    )

    playbackController = MusicPlaybackController.getInstance(this)

    // Pre-populate sample tracks or scan so the app is immediately working upon launch!
    appScope.launch {
      repository.initializeLibraryIfEmpty()
    }
  }
}

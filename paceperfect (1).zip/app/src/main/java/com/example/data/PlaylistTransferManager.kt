package com.example.data

import com.example.data.model.PlaylistEntity
import com.example.data.model.SongEntity
import org.json.JSONArray
import org.json.JSONObject

class PlaylistTransferManager {

  /**
   * Export playlist data to standard M3U text format
   */
  fun exportToM3u(playlist: PlaylistEntity, songs: List<SongEntity>): String {
    val sb = StringBuilder()
    sb.append("#EXTM3U\n")
    sb.append("#PLAYLIST:").append(playlist.name).append("\n")
    for (song in songs) {
      val durationSec = (song.durationMs / 1000).coerceAtLeast(1)
      sb.append("#EXTINF:").append(durationSec).append(",").append(song.artist).append(" - ").append(song.title).append("\n")
      sb.append(song.uriString).append("\n")
    }
    return sb.toString()
  }

  /**
   * Export playlist data to JSON format
   */
  fun exportToJson(playlist: PlaylistEntity, songs: List<SongEntity>): String {
    val json = JSONObject()
    json.put("playlistName", playlist.name)
    json.put("createdAt", playlist.createdAt)
    val songArray = JSONArray()
    for (song in songs) {
      val item = JSONObject()
      item.put("title", song.title)
      item.put("artist", song.artist)
      item.put("album", song.album)
      item.put("durationMs", song.durationMs)
      item.put("uriString", song.uriString)
      songArray.put(item)
    }
    json.put("songs", songArray)
    return json.toString(2)
  }

  data class ImportedPlaylist(
    val name: String,
    val songTitles: List<String>
  )

  /**
   * Parse either M3U or JSON text into playlist name and track titles
   */
  fun parsePlaylistText(text: String): ImportedPlaylist {
    val trimmed = text.trim()
    return if (trimmed.startsWith("{")) {
      // JSON
      try {
        val json = JSONObject(trimmed)
        val name = json.optString("playlistName", "Imported Playlist")
        val array = json.optJSONArray("songs") ?: JSONArray()
        val titles = mutableListOf<String>()
        for (i in 0 until array.length()) {
          val obj = array.getJSONObject(i)
          titles.add(obj.optString("title", "Unknown"))
        }
        ImportedPlaylist(name, titles)
      } catch (e: Exception) {
        ImportedPlaylist("Imported Playlist", emptyList())
      }
    } else {
      // M3U
      var name = "Imported Playlist"
      val titles = mutableListOf<String>()
      val lines = text.lines()
      for (line in lines) {
        val l = line.trim()
        if (l.startsWith("#PLAYLIST:")) {
          name = l.substringAfter("#PLAYLIST:").trim()
        } else if (l.startsWith("#EXTINF:")) {
          val info = l.substringAfter("#EXTINF:")
          val titlePart = info.substringAfter(",", "")
          if (titlePart.isNotBlank()) {
            val title = if (titlePart.contains(" - ")) titlePart.substringAfter(" - ") else titlePart
            titles.add(title.trim())
          }
        }
      }
      ImportedPlaylist(name, titles)
    }
  }
}

package com.example.data

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.data.model.SongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MusicFileManager(private val context: Context) {

  private val artworkDir: File = File(context.cacheDir, "artwork_cache").apply { mkdirs() }
  private val demoAudioDir: File = File(context.filesDir, "demo_audio").apply { mkdirs() }

  /**
   * Scan device MediaStore for audio tracks
   */
  suspend fun scanMediaStore(): List<SongEntity> = withContext(Dispatchers.IO) {
    val songs = mutableListOf<SongEntity>()
    val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
    } else {
      MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    }

    val projection = arrayOf(
      MediaStore.Audio.Media._ID,
      MediaStore.Audio.Media.TITLE,
      MediaStore.Audio.Media.ARTIST,
      MediaStore.Audio.Media.ALBUM,
      MediaStore.Audio.Media.DURATION,
      MediaStore.Audio.Media.SIZE,
      MediaStore.Audio.Media.DATE_ADDED,
      MediaStore.Audio.Media.MIME_TYPE
    )

    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 5000"

    try {
      context.contentResolver.query(
        collection,
        projection,
        selection,
        null,
        "${MediaStore.Audio.Media.TITLE} ASC"
      )?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
        val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
        val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)

        while (cursor.moveToNext()) {
          val id = cursor.getLong(idCol)
          val title = cursor.getString(titleCol) ?: "Unknown Title"
          val artist = cursor.getString(artistCol) ?: "Unknown Artist"
          val album = cursor.getString(albumCol) ?: "Unknown Album"
          val duration = cursor.getLong(durationCol)
          val size = cursor.getLong(sizeCol)
          val dateAdded = cursor.getLong(dateAddedCol)
          val mime = cursor.getString(mimeCol) ?: "audio/mpeg"

          val contentUri = ContentUris.withAppendedId(collection, id).toString()
          val artUri = extractArtwork(Uri.parse(contentUri), id)

          songs.add(
            SongEntity(
              title = title,
              artist = if (artist == "<unknown>") "Unknown Artist" else artist,
              album = if (album == "<unknown>") "Unknown Album" else album,
              durationMs = duration,
              uriString = contentUri,
              artworkUri = artUri,
              dateAdded = dateAdded * 1000L,
              fileSizeBytes = size,
              mimeType = mime,
              folderName = "Storage"
            )
          )
        }
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }

    songs
  }

  /**
   * Import a single file selected by the user via Intent.ACTION_OPEN_DOCUMENT or GET_CONTENT
   */
  suspend fun importAudioUri(uri: Uri): SongEntity? = withContext(Dispatchers.IO) {
    try {
      val retriever = MediaMetadataRetriever()
      retriever.setDataSource(context, uri)

      val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
        ?: uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.')
        ?: "Imported Track"
      val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "Unknown Artist"
      val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "Imported Album"
      val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
      val durationMs = durationStr?.toLongOrNull() ?: 180000L
      val mimeType = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "audio/mpeg"

      val artUri = extractArtwork(uri, System.currentTimeMillis())
      retriever.release()

      SongEntity(
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        uriString = uri.toString(),
        artworkUri = artUri,
        dateAdded = System.currentTimeMillis(),
        folderName = "Imported",
        mimeType = mimeType
      )
    } catch (e: Exception) {
      e.printStackTrace()
      null
    }
  }

  /**
   * Extract embedded album artwork from audio file and cache it locally
   */
  private fun extractArtwork(uri: Uri, identifier: Long): String? {
    val artFile = File(artworkDir, "art_$identifier.jpg")
    if (artFile.exists() && artFile.length() > 0) {
      return artFile.absolutePath
    }

    var retriever: MediaMetadataRetriever? = null
    return try {
      retriever = MediaMetadataRetriever()
      retriever.setDataSource(context, uri)
      val picture = retriever.embeddedPicture
      if (picture != null) {
        FileOutputStream(artFile).use { fos ->
          fos.write(picture)
        }
        artFile.absolutePath
      } else {
        null
      }
    } catch (e: Exception) {
      null
    } finally {
      try {
        retriever?.release()
      } catch (ignored: Exception) {}
    }
  }

  /**
   * Generates playable demo/sample audio tracks (pure PCM 16-bit WAV with musical chords/arpeggios)
   * so the emulator or first-time user has fully functioning high-fidelity audio out of the box!
   */
  suspend fun ensureDemoTracksExist(): List<SongEntity> = withContext(Dispatchers.IO) {
    val demoList = listOf(
      DemoTrackDef("Neon Horizon", "Synthwave Collective", "Retro Odyssey", 220.0, 14000L),
      DemoTrackDef("Midnight Groove", "Aura Beats", "Chill Sessions", 174.6, 16000L),
      DemoTrackDef("Cyber Pulse", "Techno Nomad", "Circuit Dreams", 261.6, 12000L),
      DemoTrackDef("Solar Drift", "Cosmic Echo", "Infinite Horizon", 196.0, 15000L),
      DemoTrackDef("Lo-Fi Rain", "Velvet Coffee", "Late Night Study", 130.8, 18000L)
    )

    val generatedSongs = mutableListOf<SongEntity>()

    for ((index, def) in demoList.withIndex()) {
      val wavFile = File(demoAudioDir, "demo_track_${index + 1}.wav")
      if (!wavFile.exists() || wavFile.length() == 0L) {
        generateMusicalWav(wavFile, def.baseFreq, def.durationMs)
      }

      generatedSongs.add(
        SongEntity(
          title = def.title,
          artist = def.artist,
          album = def.album,
          durationMs = def.durationMs,
          uriString = Uri.fromFile(wavFile).toString(),
          artworkUri = null,
          dateAdded = System.currentTimeMillis() - (index * 86400000L),
          folderName = "Demo Tracks",
          mimeType = "audio/wav",
          fileSizeBytes = wavFile.length()
        )
      )
    }

    generatedSongs
  }

  /**
   * Synthesize a clean 44.1kHz 16-bit stereo musical audio WAV file with chord harmony & envelope
   */
  private fun generateMusicalWav(outputFile: File, baseFreq: Double, durationMs: Long) {
    val sampleRate = 44100
    val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
    val bytesPerSample = 2 // 16-bit
    val channels = 2
    val dataSize = numSamples * channels * bytesPerSample

    FileOutputStream(outputFile).use { out ->
      // Write WAV Header
      val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
      header.put("RIFF".toByteArray())
      header.putInt(36 + dataSize)
      header.put("WAVE".toByteArray())
      header.put("fmt ".toByteArray())
      header.putInt(16) // Subchunk1Size for PCM
      header.putShort(1) // AudioFormat 1 = PCM
      header.putShort(channels.toShort())
      header.putInt(sampleRate)
      header.putInt(sampleRate * channels * bytesPerSample) // ByteRate
      header.putShort((channels * bytesPerSample).toShort()) // BlockAlign
      header.putShort((bytesPerSample * 8).toShort()) // BitsPerSample
      header.put("data".toByteArray())
      header.putInt(dataSize)
      out.write(header.array())

      // Chord ratios: Root, Major Third (5/4), Fifth (3/2), Octave (2/1)
      val f1 = baseFreq
      val f2 = baseFreq * 1.2599 // Minor/Major harmony
      val f3 = baseFreq * 1.4983 // Fifth
      val f4 = baseFreq * 2.0

      val buffer = ByteBuffer.allocate(sampleRate * channels * bytesPerSample).order(ByteOrder.LITTLE_ENDIAN)
      var sampleIdx = 0

      while (sampleIdx < numSamples) {
        buffer.clear()
        val chunkSamples = minOf(sampleRate, numSamples - sampleIdx)
        for (i in 0 until chunkSamples) {
          val t = (sampleIdx + i).toDouble() / sampleRate
          // Smooth attack and release envelope
          val envelope = when {
            t < 0.2 -> (t / 0.2)
            t > (durationMs / 1000.0) - 0.5 -> (((durationMs / 1000.0) - t) / 0.5).coerceAtLeast(0.0)
            else -> 1.0
          }
          // Musical tone with subtle rhythm tremolo
          val beat = 0.85 + 0.15 * Math.sin(2.0 * Math.PI * 2.5 * t)
          val s1 = Math.sin(2.0 * Math.PI * f1 * t)
          val s2 = 0.5 * Math.sin(2.0 * Math.PI * f2 * t)
          val s3 = 0.35 * Math.sin(2.0 * Math.PI * f3 * t)
          val s4 = 0.2 * Math.sin(2.0 * Math.PI * f4 * t)
          val mixed = (s1 + s2 + s3 + s4) / 2.05 * envelope * beat

          val sampleVal = (mixed * 24000).toInt().coerceIn(-32767, 32767).toShort()
          // Stereo channels with slight pan phase
          val leftVal = (sampleVal * (0.8 + 0.2 * Math.cos(2.0 * Math.PI * 0.5 * t))).toInt().toShort()
          val rightVal = (sampleVal * (0.8 + 0.2 * Math.sin(2.0 * Math.PI * 0.5 * t))).toInt().toShort()

          buffer.putShort(leftVal)
          buffer.putShort(rightVal)
        }
        out.write(buffer.array(), 0, chunkSamples * channels * bytesPerSample)
        sampleIdx += chunkSamples
      }
    }
  }

  fun getCacheSizeBytes(): Long {
    var size = 0L
    artworkDir.listFiles()?.forEach { size += it.length() }
    return size
  }

  suspend fun cleanStorageCache(): Long = withContext(Dispatchers.IO) {
    var deletedBytes = 0L
    artworkDir.listFiles()?.forEach {
      val len = it.length()
      if (it.delete()) {
        deletedBytes += len
      }
    }
    deletedBytes
  }

  private data class DemoTrackDef(
    val title: String,
    val artist: String,
    val album: String,
    val baseFreq: Double,
    val durationMs: Long
  )
}

package com.example.data

import android.net.Uri
import com.example.data.dao.PlaylistDao
import com.example.data.dao.QueueDao
import com.example.data.dao.SongDao
import com.example.data.model.PlaylistEntity
import com.example.data.model.PlaylistSongCrossRef
import com.example.data.model.SongEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MusicRepository(
  private val songDao: SongDao,
  private val playlistDao: PlaylistDao,
  private val queueDao: QueueDao,
  private val fileManager: MusicFileManager,
  private val transferManager: PlaylistTransferManager = PlaylistTransferManager()
) {

  val allSongs: Flow<List<SongEntity>> = songDao.getAllSongs()
  val favoriteSongs: Flow<List<SongEntity>> = songDao.getFavorites()
  val allPlaylists: Flow<List<PlaylistEntity>> = playlistDao.getAllPlaylists()
  val queueSongs: Flow<List<SongEntity>> = queueDao.getQueueSongs()

  suspend fun initializeLibraryIfEmpty() {
    val current = songDao.getAllSongs().first()
    if (current.isEmpty()) {
      // 1. Try scanning MediaStore
      val mediaStoreSongs = fileManager.scanMediaStore()
      if (mediaStoreSongs.isNotEmpty()) {
        songDao.insertSongs(mediaStoreSongs)
      } else {
        // 2. Generate initial high quality demo tracks so the user has immediate audio playback
        val demos = fileManager.ensureDemoTracksExist()
        songDao.insertSongs(demos)
      }
    }
  }

  suspend fun scanDeviceLibrary(): Int {
    val mediaStoreSongs = fileManager.scanMediaStore()
    if (mediaStoreSongs.isNotEmpty()) {
      songDao.insertSongs(mediaStoreSongs)
    }
    return mediaStoreSongs.size
  }

  suspend fun addDemoPack(): Int {
    val demos = fileManager.ensureDemoTracksExist()
    songDao.insertSongs(demos)
    return demos.size
  }

  suspend fun importAudioUri(uri: Uri): SongEntity? {
    val song = fileManager.importAudioUri(uri)
    if (song != null) {
      val id = songDao.insertSong(song)
      return song.copy(id = id)
    }
    return null
  }

  suspend fun toggleFavorite(song: SongEntity) {
    songDao.setFavorite(song.id, !song.isFavorite)
  }

  suspend fun updateSongMetadata(id: Long, newTitle: String, newArtist: String, newAlbum: String) {
    val existing = songDao.getSongById(id) ?: return
    songDao.updateSong(
      existing.copy(
        title = newTitle.trim().ifEmpty { existing.title },
        artist = newArtist.trim().ifEmpty { existing.artist },
        album = newAlbum.trim().ifEmpty { existing.album }
      )
    )
  }

  suspend fun deleteSong(song: SongEntity) {
    songDao.deleteSong(song)
    queueDao.removeSongFromQueue(song.id)
  }

  suspend fun createPlaylist(name: String): Long {
    val trimmed = name.trim().ifEmpty { "My Playlist" }
    return playlistDao.insertPlaylist(PlaylistEntity(name = trimmed))
  }

  suspend fun deletePlaylist(playlist: PlaylistEntity) {
    playlistDao.clearPlaylistSongs(playlist.id)
    playlistDao.deletePlaylist(playlist)
  }

  suspend fun addSongToPlaylist(playlistId: Long, songId: Long) {
    playlistDao.addSongToPlaylist(
      PlaylistSongCrossRef(
        playlistId = playlistId,
        songId = songId,
        orderIndex = System.currentTimeMillis().toInt()
      )
    )
  }

  suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
    playlistDao.removeSongFromPlaylist(playlistId, songId)
  }

  fun getSongsForPlaylist(playlistId: Long): Flow<List<SongEntity>> {
    return playlistDao.getSongsForPlaylist(playlistId)
  }

  fun getSongCountForPlaylist(playlistId: Long): Flow<Int> {
    return playlistDao.getSongCountForPlaylist(playlistId)
  }

  suspend fun updateQueue(songs: List<SongEntity>) {
    queueDao.replaceQueue(songs)
  }

  fun getCacheSizeBytes(): Long = fileManager.getCacheSizeBytes()

  suspend fun cleanStorageCache(): Long = fileManager.cleanStorageCache()

  suspend fun exportPlaylist(playlistId: Long): String {
    val playlist = playlistDao.getPlaylistById(playlistId) ?: return ""
    val songs = playlistDao.getSongsForPlaylist(playlistId).first()
    return transferManager.exportToM3u(playlist, songs)
  }

  suspend fun importPlaylistFromText(text: String): Long {
    val imported = transferManager.parsePlaylistText(text)
    val playlistId = playlistDao.insertPlaylist(PlaylistEntity(name = imported.name))
    val all = songDao.getAllSongs().first()
    for (title in imported.songTitles) {
      val match = all.firstOrNull { it.title.equals(title, ignoreCase = true) }
      if (match != null) {
        playlistDao.addSongToPlaylist(PlaylistSongCrossRef(playlistId, match.id))
      }
    }
    return playlistId
  }
}

package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.PlaylistEntity
import com.example.data.model.PlaylistSongCrossRef
import com.example.data.model.SongEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
  @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE ASC")
  fun getAllPlaylists(): Flow<List<PlaylistEntity>>

  @Query("SELECT * FROM playlists WHERE id = :id LIMIT 1")
  suspend fun getPlaylistById(id: Long): PlaylistEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPlaylist(playlist: PlaylistEntity): Long

  @Update
  suspend fun updatePlaylist(playlist: PlaylistEntity)

  @Delete
  suspend fun deletePlaylist(playlist: PlaylistEntity)

  @Query("DELETE FROM playlists WHERE id = :id")
  suspend fun deletePlaylistById(id: Long)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun addSongToPlaylist(crossRef: PlaylistSongCrossRef)

  @Query("DELETE FROM playlist_song_cross_ref WHERE playlistId = :playlistId AND songId = :songId")
  suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long)

  @Query("DELETE FROM playlist_song_cross_ref WHERE playlistId = :playlistId")
  suspend fun clearPlaylistSongs(playlistId: Long)

  @Query("""
    SELECT s.* FROM songs s
    INNER JOIN playlist_song_cross_ref ref ON s.id = ref.songId
    WHERE ref.playlistId = :playlistId
    ORDER BY ref.orderIndex ASC
  """)
  fun getSongsForPlaylist(playlistId: Long): Flow<List<SongEntity>>

  @Query("SELECT COUNT(*) FROM playlist_song_cross_ref WHERE playlistId = :playlistId")
  fun getSongCountForPlaylist(playlistId: Long): Flow<Int>
}

package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "songs")
data class SongEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0L,
  val title: String,
  val artist: String,
  val album: String,
  val durationMs: Long,
  val uriString: String,
  val artworkUri: String? = null,
  val dateAdded: Long = System.currentTimeMillis(),
  val isFavorite: Boolean = false,
  val folderName: String = "Music",
  val mimeType: String = "audio/mpeg",
  val fileSizeBytes: Long = 0L
)

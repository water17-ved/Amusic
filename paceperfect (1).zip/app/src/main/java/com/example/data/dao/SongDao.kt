package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.SongEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SongDao {
  @Query("SELECT * FROM songs ORDER BY title COLLATE NOCASE ASC")
  fun getAllSongs(): Flow<List<SongEntity>>

  @Query("SELECT * FROM songs WHERE isFavorite = 1 ORDER BY title COLLATE NOCASE ASC")
  fun getFavorites(): Flow<List<SongEntity>>

  @Query("SELECT * FROM songs WHERE id = :id LIMIT 1")
  suspend fun getSongById(id: Long): SongEntity?

  @Query("SELECT * FROM songs WHERE uriString = :uriString LIMIT 1")
  suspend fun getSongByUri(uriString: String): SongEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSong(song: SongEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSongs(songs: List<SongEntity>): List<Long>

  @Update
  suspend fun updateSong(song: SongEntity)

  @Delete
  suspend fun deleteSong(song: SongEntity)

  @Query("DELETE FROM songs WHERE id = :id")
  suspend fun deleteSongById(id: Long)

  @Query("DELETE FROM songs")
  suspend fun deleteAllSongs()

  @Query("UPDATE songs SET isFavorite = :isFavorite WHERE id = :id")
  suspend fun setFavorite(id: Long, isFavorite: Boolean)

  @Query("SELECT * FROM songs WHERE title LIKE '%' || :query || '%' OR artist LIKE '%' || :query || '%' OR album LIKE '%' || :query || '%' ORDER BY title COLLATE NOCASE ASC")
  fun searchSongs(query: String): Flow<List<SongEntity>>

  @Query("SELECT * FROM songs WHERE artist = :artist ORDER BY title COLLATE NOCASE ASC")
  fun getSongsByArtist(artist: String): Flow<List<SongEntity>>

  @Query("SELECT * FROM songs WHERE album = :album ORDER BY title COLLATE NOCASE ASC")
  fun getSongsByAlbum(album: String): Flow<List<SongEntity>>
}

package com.example.data.model

import androidx.room.Entity
import androidx.room.Index

@Entity(
  tableName = "playlist_song_cross_ref",
  primaryKeys = ["playlistId", "songId"],
  indices = [Index(value = ["songId"])]
)
data class PlaylistSongCrossRef(
  val playlistId: Long,
  val songId: Long,
  val orderIndex: Int = 0
)

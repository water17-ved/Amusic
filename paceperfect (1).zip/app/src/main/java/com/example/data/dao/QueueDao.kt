package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.QueueItemEntity
import com.example.data.model.SongEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface QueueDao {
  @Query("SELECT * FROM queue_items ORDER BY orderIndex ASC")
  fun getQueueItems(): Flow<List<QueueItemEntity>>

  @Query("""
    SELECT s.* FROM songs s
    INNER JOIN queue_items q ON s.id = q.songId
    ORDER BY q.orderIndex ASC
  """)
  fun getQueueSongs(): Flow<List<SongEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertQueueItem(item: QueueItemEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertQueueItems(items: List<QueueItemEntity>)

  @Query("DELETE FROM queue_items")
  suspend fun clearQueue()

  @Query("DELETE FROM queue_items WHERE songId = :songId")
  suspend fun removeSongFromQueue(songId: Long)

  @Transaction
  suspend fun replaceQueue(songs: List<SongEntity>) {
    clearQueue()
    val items = songs.mapIndexed { index, song ->
      QueueItemEntity(songId = song.id, orderIndex = index)
    }
    insertQueueItems(items)
  }
}

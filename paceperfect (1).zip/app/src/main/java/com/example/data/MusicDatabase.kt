package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.PlaylistDao
import com.example.data.dao.QueueDao
import com.example.data.dao.SongDao
import com.example.data.model.PlaylistEntity
import com.example.data.model.PlaylistSongCrossRef
import com.example.data.model.QueueItemEntity
import com.example.data.model.SongEntity

@Database(
  entities = [
    SongEntity::class,
    PlaylistEntity::class,
    PlaylistSongCrossRef::class,
    QueueItemEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class MusicDatabase : RoomDatabase() {
  abstract fun songDao(): SongDao
  abstract fun playlistDao(): PlaylistDao
  abstract fun queueDao(): QueueDao

  companion object {
    @Volatile
    private var INSTANCE: MusicDatabase? = null

    fun getInstance(context: Context): MusicDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          MusicDatabase::class.java,
          "music_database.db"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
